# 📦 Bornforthis Library Python EasyDB

## What?

该库可以使你快速写入你想写入数据库的数据，基于：sqlite3、pymongo、sqlalchemy 的二次开发。

## Install

```python
pip install EasyDB
```

## Use

```python
......
```