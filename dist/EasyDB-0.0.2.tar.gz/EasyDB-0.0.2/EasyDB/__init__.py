from EasyDB.SqliteOperation import SqliteOperation
from EasyDB.MongoDB import Mongodb
